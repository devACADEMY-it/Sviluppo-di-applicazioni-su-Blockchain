import Web3 from 'web3'
import json_conf from '../build/contracts/Donations.json'
const ADDRESS = json_conf.networks['5777'].address
const ABI = json_conf.abi
const web3 = new Web3(
  Web3.givenProvider || 'http://127.0.0.1:8545'
)

const contract = new web3.eth.Contract(ABI,ADDRESS)

const click_donate = async function(){
	const accounts=await web3.eth.requestAccounts()
	account=accounts[0]
	
	value=$("#value").val()
	message=$("#message").val()
	
	contract.methods.donate(message).send({"from":account, 
	     "value": web3.utils.toWei(value,'ether')})
	.on("confirmation", function(confirmationNumber, receipt){
		alert("Grazie per la tua donazione!")
		$("#value").val('')
	    $("#message").val('')
		update()
	})
	
	
}

async function update(){
	balance=await contract.methods.getContractBalance().call()
	balance=web3.utils.fromWei(balance,'ether')
	$("#balance").text(balance)
}

$(document).ready(
   function(){
	 $("#btn_donate").click(click_donate)
	 update()
   }
)