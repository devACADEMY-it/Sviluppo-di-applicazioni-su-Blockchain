import Web3 from 'web3'
import json_conf from '../build/contracts/Calculator.json'
const ADDRESS = json_conf.networks['5777'].address
const ABI = json_conf.abi
const web3 = new Web3(
  Web3.givenProvider || 'http://127.0.0.1:8545'
)

const calculator = new web3.eth.Contract(ABI,ADDRESS)

async function read_bc_value(){
	const value_from_bc = await calculator.methods.getValue().call()
	$("#result").text(value_from_bc)
}

const click_add = async function(){
	const accounts=await web3.eth.requestAccounts()
	account=accounts[0]
	
	value=$("#value").val()
	calculator.methods.add(value).send({"from":account})
	.on('confirmation', function(confirmationNumber, receipt){
		alert('Transazione completata!')
		$("#value").val('')
	})
}

$(document).ready(
function(){
	read_bc_value()
	$("#btn_add").click(click_add)
	$("#btn_sub").click(
	function(){
		alert("Cliccato Sub")
           }
        )
	
}
)